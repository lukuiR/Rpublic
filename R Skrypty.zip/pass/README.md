Based on https://gist.github.com/withr/9001831

Username: test  
Password: 123
