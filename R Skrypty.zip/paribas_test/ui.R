library(shiny)
library(shinydashboard)
library(DT)
library(leaflet)
library(plotly)

#data

dashboardPage(skin = "green",
              dashboardHeader(title = "bgz bnp paribas",
                  tags$li(class = "dropdown",
                      tags$a(href="http://b2e.group.echonet/pid65815-lid11/bga-bnp-paribas.html", target="_blank", 
                            tags$img(height = "20px", alt="SNAP Logo", src="http://rankingfirmfaktoringowych.pl/wp-content/uploads/2016/08/logo-bgzbnp-300x105.png")
                            )
                          )
                    ),
              
              dashboardSidebar(
                    sidebarMenu(
                         id = "tabs",
                          menuItem("Start", icon = icon("info"), tabName = "tab1"),
                          menuItem("Sala nr 103", icon = icon("line-chart"), tabName = "dashboard")
                      )
                  ),
              
              dashboardBody(
                      tabItems(
                             tabItem(tabName = "tab1",
                                  img(src='http://rankingfirmfaktoringowych.pl/wp-content/uploads/2016/08/logo-bgzbnp-300x105.png', width='40%' ,style="display: block; margin-left: auto; margin-right: auto;")
                                  ,
                                  h4(HTML("Aplikacja powstała w&nbspramach projektu pn."), align = "center"),
                                  h4(HTML('<b>"Poprawa jakości powietrza wewnętrznego w&nbsppolskich placówkach edukacyjnych – działania w Szkole Podstawowej nr&nbsp10 w&nbspLubinie"</b>'), align = "center"),
                                  fluidRow( valueBoxOutput("value1")
                                            ,valueBoxOutput("value2")
                                            ,valueBoxOutput("value3"),
                                            
                                            
                                            
                                            valueBoxOutput("box_03"),
                                            textOutput("print")
                                    ),
                                  fluidRow( conditionalPanel(condition="$('html').hasClass('shiny-busy')", 
                                                             #poniżej https://fontawesome.com/how-to-use/svg-with-js
                                                             tags$div("Wczytywanie...",HTML('<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
                                                                                          <span class="sr-only">Loading...</span>'),id="loadmessage")),
                                            align = "center"),
                                      fluidRow(
                                        radioButtons("radio", h3("Wybierz grupowanie"),
                                                     choices = list("Waga" = "WAGA", "Supergrupa" = "SUPERGRUPA",
                                                                    "Memonik" = "MNEMONIK_ODBIORCY"),inline = TRUE,selected = "WAGA"),
                                        verbatimTextOutput("hover"),
                                        verbatimTextOutput("click"),
                                        verbatimTextOutput("brush"),
                                        verbatimTextOutput("zoom"),
                                       textOutput("text"),
                                        plotlyOutput("plot4"),
                                       dataTableOutput(outputId = "dt"),
                                       dataTableOutput(outputId = "dt2")
                                      ),
                                      h4(HTML('<a href="http://www.aerisqualitas.org"><b>www.aerisqualitas.org</b></a>'), align = "center"),br()
                                      ,align = "center",
                                      h6("Copyright aeris qualitas & Łukasz Janiszewski 2017", align = "center")
                                      
                              ),
                              tabItem(
                                tabName = "dashboard",
                                fluidRow(
                                  h2("Jakość powietrza w sali dydaktycznej nr 103 jest:", align = "center")
                                ),
                                h2(HTML( '<b><font color=#35528E>' ,  
                                  paste("BARDZO DOBRA"),'</b></font>' ), align = "center"),
                                br(),
                                fluidRow( conditionalPanel(condition="$('html').hasClass('shiny-busy')", 
                                                           #poniżej https://fontawesome.com/how-to-use/svg-with-js
                                                           tags$div("Wczytywanie...",HTML('<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
                                                                                          <span class="sr-only">Loading...</span>'),id="loadmessage")),
                                          align = "center"),
                                fluidRow(
                                  plotlyOutput("pie")
                                
                                )
                                
                                                           )
                              )
                            
)
)


# Put them together into a dashboardPage