library(plotly)
library(RColorBrewer)
library(DT)
#read cvs



dt = as.data.table(mtcars)

shinyServer(function(input, output, session) {
  set.seed(122)
  
  zz <- reactive({z[,c("DATA","BLEDY",input$radio)]    })
  
  ######graph
  output$plot4 <- renderPlotly(
    plot_ly(x=zz()$DATA,y=zz()$BLEDY,
            color = zz()[,3]
    )%>%layout( barmode='stack', margin = list(b = 80), xaxis = list(tickangle = 45))
    
  )

  
 output$text<-renderText(paste(" i ", try(input$plot4_legend_click)))
 
 
  
  ###############  kpi 
  output$value1 <- renderValueBox({
  valueBox(
    formatC(sum(oracl[oracl$DATA==max(oracl$DATA),"BLEDY"]), format="d", big.mark=','),width=
      ,paste('Bledy')
    ,icon = icon("stats",lib='glyphicon')
    ,color = "purple")
  })
  output$value2 <- renderValueBox({ 
    valueBox(
      formatC(sum(oracl[oracl$DATA==max(oracl$DATA),"BLEDY_POPRAWIONE"]), format="d", big.mark=','),width=
        ,paste('Bledy Poprawione')
      ,icon = icon("glyphicon glyphicon-wrench",lib='glyphicon')
      ,color = "green")
  })
    output$value3 <- renderValueBox({ valueBox(
        formatC(sum(oracl[oracl$DATA==max(oracl$DATA),"BLEDY_NOWE"]), format="d", big.mark=','),width=
          ,paste('Bledy Nowe')
        ,icon = icon("glyphicon glyphicon-remove-sign",lib='glyphicon')
        ,color = "red")
    })

  ###############    
    output$hover <- renderPrint({
      d <- event_data("plotly_hover")
      if (is.null(d)) "Hover events appear here (unhover to clear)" else d
    })
    
    output$click <- renderPrint({
      d <- event_data("plotly_click")
      if (is.null(d)) "Click events appear here (double-click to clear)" else d
    })
    
    output$brush <- renderPrint({
      d <- event_data("plotly_selected")
      if (is.null(d)) "Click and drag events (i.e., select/lasso) appear here (double-click to clear)" else d
    })
    
    output$zoom <- renderPrint({
      d <- event_data("plotly_relayout")
      if (is.null(d)) "Relayout (i.e., zoom) events appear here" else d
    })

  
  #######table
    
    output$dt3<- renderDataTable(
      z[,c(7,5,1,10,11,12)], options = list(
        deferRender = TRUE,scrollX = TRUE, autoWidth = TRUE,
        scrollY = 200,
        scroller = TRUE)
    )
    
    output$dt2<- renderDataTable(
      z[,c(7,5,1,10,11,12)],
      escape = -2,
      extensions = c('FixedHeader', 'Buttons', 'ColReorder', 'Scroller'),
      options = list(
        dom = 'Bfrti',
        autoWidth = FALSE,
        colReorder = TRUE,
        deferRender = TRUE,
        scrollX = TRUE,
        scrollY = "51vh",
        scroller = TRUE,
        scollCollapse = TRUE,
        fixedHeader = TRUE,
        columnDefs = list(
          list(orderable = FALSE, className = 'details-control', targets = 0)
        )
      )
    )
    
    
    
    
    
    
    ##############
    
    gearDT <- dt[,.N,by=gear] 
    cylDT <- dt[,.N,by=cyl]
    
    output$pie <- renderPlotly({
      
      plot_ly() %>%
        add_pie(data = gearDT, labels = ~gear, values = ~N, name = "gear",
                domain = list(x = c(0, 0.5), y = c(0, 1))) %>%
        add_pie(data = cylDT, labels = ~cyl, values = ~N, name = "cyl",
                domain = list(x = c(0.5, 1), y = c(0, 1))) %>%
        layout(showlegend = TRUE,
               xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
               yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
      

    })

##########
    output$box_03 <- renderValueBox({
      entry_01<-20
      box3<-valueBox(value=entry_01
                     ,icon = icon("users",lib="font-awesome")
                     ,width=NULL
                     ,color = "blue"
                     ,href="#"
                     ,subtitle=HTML("<b>Test click on valueBox</b>")
      )
      box3$children[[1]]$attribs$class<-"action-button"
      box3$children[[1]]$attribs$id<-"button_box_03"
      return(box3)
    })
    
    output$print<-renderText({
      print(input$button_box_03)
    })
    
    ############
  
})