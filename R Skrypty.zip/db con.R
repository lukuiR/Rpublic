#PWD = rstudioapi::askForPassword("Database password")
#mssql con

install.packages(RODBC)#i to pozniej mo�na u�ywa� analogicznie do innych bibliotek, zainstalowa� wystarczy tylko raz.
library(RODBC)
dbhandle <-odbcDriverConnect('driver={SQL Server};server=sqlsrv,1433;database=bjd;trusted_connection=true')


dbhandle <-odbcDriverConnect('driver={SQL Server};server=CENTSQL-DB05,1433;trusted_connection=true')


currTableSQL<-paste("select * from [Krupier].[dbo].[TransactionArchive] ",sep="")


tarch<-sqlQuery(dbhandle,currTableSQL)


currTableSQL<-paste("select * from Quality_Control.dbo.stat_grupy ",sep="")
currTableDF<-sqlQuery(dbhandle,q2)
odbcClose(dbhandle)
#sqlQuery(conn, read_sql("sql_query.sql"))

dbconnection <- odbcDriverConnect("PI;trusted_connection=true")
dbconnection <- odbcConnect("pi;trusted_connection=true")

dbconnection <- odbcConnect("bjd")


o_grp <- sqlQuery(dbconnection, q1)
alg <- sqlQuery(dbconnection, q4)
met_kon <- sqlQuery(dbconnection, "select * from pi_dane. sl_metryka_kontroli")

tt <- sqlQuery(dbconnection, "select top 10 * from omr.[dbo].[tImp_FX_FORWARD] ")

o_id <- sqlQuery(dbconnection, q3)
gr_id <- sqlQuery(dbconnection, q6)
errmd5 <- sqlQuery(dbconnection, q7)

odbcClose(dbhandle)

library(rJava)

# Load RJDBC library
library(RJDBC)

# Create connection driver and open connection
jdbcDriver <- JDBC(driverClass="oracle.jdbc.OracleDriver", classPath="C:\\Oracle\\product\\12.1.0\\client_1\\jdbc\\lib\\ojdbc7.jar")
jdbcConnection <- 
  dbConnect(jdbcDriver, "jdbc:oracle:thin:@piexa-scan:1521/pitst", "JANISZEWSKI6", rstudioapi::askForPassword("Database password"))

jdbcConnection <- 
  dbConnect(jdbcDriver, "jdbc:oracle:thin:@piexa-scan:1521/pi", "JANISZEWSKI6", rstudioapi::askForPassword("Database password"))


# Query on the Oracle instance name.
o_grp2 <- dbGetQuery(jdbcConnection, q1)
obsz_kon<-dbGetQuery(jdbcConnection, "select * from pi_dane. sl_obszar_kontroli")
met_kon2<-dbGetQuery(jdbcConnection, "select * from pi_dane. sl_metryka_kontroli")
alg2 <- dbGetQuery(jdbcConnection, q4)
o_id<- dbGetQuery(jdbcConnection, q3)
last<- dbGetQuery(jdbcConnection, q5)


dbWriteTable(con,"TEST_TABLE", test_table)
dbGetQuery(con,"select count(*) from TEST_TABLE")
d <- dbReadTable(con, "TEST_TABLE")
dbDisconnect(jdbcConnection)

mssql<-sqlQuery(dbhandle,q2)
oracl <- dbGetQuery(jdbcConnection, q1)

#SELECT mail_mnemonik ,REGEXP_SUBSTR(mail_adres, '[^;]+', 1, LEVEL)
#FROM PI_DANE.st_mail
#CONNECT BY
#REGEXP_SUBSTR(mail_adres, '[^;]+', 1, LEVEL) IS NOT NULL;

jdbcConnection <- 
  dbConnect(jdbcDriver, "jdbc:oracle:thin:@piexa-scan:1521:pi", "JANISZEWSKI6", "Pentium12")

jdbcConnection <- 
  dbConnect(jdbcDriver, "JANISZEWSKI,@//piexa-scan:1521:pitst")





Sys.setenv("JAVA_TOOL_OPTIONS"="-Djava.security.auth.login.config=/Oracle/product/12.1.0/client_1/network/admin/krb5.conf -Djavax.security.auth.useSubjectCredsOnly=false")


o_grp=o_grp1
met_kon=met_kon1
alg=alg1

write.csv(o_grp1,file="o_gr_p.csv")
write.csv(o_grp2,file="o_gr_t.csv")
write.csv(o_id,file="o_id_t.csv")

o_grp2<-read.csv("o_gr_p.csv",header = TRUE)[,2:9]
o_grp1<-read.csv("o_gr_t.csv",header = TRUE)[,2:9]
o_id<-read.csv("o_id_t.csv",header = TRUE)[,2:10]

write.csv(alg1,file="alg_p.csv")
alg<-read.csv("alg_t.csv",header = TRUE)[,2:4]

write.csv(alg2,file="alg_t.csv")
write.csv(met_kon1,file="met_p.csv")
met_kon<-read.csv("met_t.csv",header = TRUE)[,2:12]

write.csv(met_kon2,file="met_t.csv")

errmd5_gr=merge(errmd5,gr_id)
errmd5_gr<-errmd5_gr[,c(2,9,1,6)]
errmd5<-NULL
rm(errmd5)

z=merge(x=o_grp1, y=met_kon, by = "GRUPA_ALGORYTMU", all = TRUE)
z$MNEMONIK_ODBIORCY<-as.character(z$MNEMONIK_ODBIORCY)
z$MNEMONIK_ODBIORCY[is.na(z$MNEMONIK_ODBIORCY)] <- 'missing'

z$DATA<-as.character(z$DATA)
z$DATA[is.na(z$DATA)] <- '0/0/0'

z1=z[z$MNEMONIK_ODBIORCY=='OK',c("GRUPA_ALGORYTMU","DATA","BLEDY")]
z2=merge(x=z, y=z1, by = c("GRUPA_ALGORYTMU","DATA"), all.x = TRUE)
z2= transform(z2, RATIO = 1-z2$BLEDY.x/z2$BLEDY.y)
z2$TRESHOLD <- ifelse(z2$RATIO>=0.8, ifelse(z2$RATIO>=0.95, "super", "akceptowalne"), "zle")
z2$TRESHOLD[is.na(z2$TRESHOLD)]<-"missing"
z2$WAGA_KONTROLI<-as.character(z2$WAGA_KONTROLI)
z2$WAGA_KONTROLI[is.na(z2$WAGA_KONTROLI)]<-"missing"


za=aggregate(z2$BLEDY.x[z2$MNEMONIK_ODBIORCY!='OK'], by=z2[z2$MNEMONIK_ODBIORCY!='OK' ,c(1,2,9,12,19)], sum )
colnames(za)[6]<-'BLEDY'

za= transform(za, RATIO = 1-za$BLEDY/za$BLEDY.y)
za$TRESHOLD <- ifelse(za$RATIO>=0.8, ifelse(za$RATIO>=0.95, "super", "akceptowalne"), "zle")

zi=merge(x=o_id, y=met_kon, by = "GRUPA_ALGORYTMU", all = TRUE)

zi$MNEMONIK_ODBIORCY<-as.character(zi$MNEMONIK_ODBIORCY)
zi$MNEMONIK_ODBIORCY[is.na(zi$MNEMONIK_ODBIORCY)] <- 'missing'

zi$DATA<-as.character(zi$DATA)
zi$DATA[is.na(zi$DATA)] <- '0/0/0'

z1i=zi[zi$MNEMONIK_ODBIORCY=='OK',c("GRUPA_ALGORYTMU","ID_ALGORYTMU","DATA","BLEDY")]
z2i=merge(x=zi, y=z1i, by = c("GRUPA_ALGORYTMU","ID_ALGORYTMU","DATA"), all.x = TRUE)


z2i= transform(z2i, RATIO = 1-z2i$BLEDY.x/z2i$BLEDY.y)
z2i$TRESHOLD <- ifelse(z2i$RATIO>=0.8, ifelse(z2i$RATIO>=0.95, "super", "akceptowalne"), "zle")
z2i$TRESHOLD[is.na(z2i$TRESHOLD)]<-"missing"

z2i$WAGA_KONTROLI<-as.character(z2i$WAGA_KONTROLI)
z2i$WAGA_KONTROLI[is.na(z2i$WAGA_KONTROLI)]<-"missing"

zia=aggregate(z2i$BLEDY.x[z2i$MNEMONIK_ODBIORCY!='OK'], by=z2i[z2i$MNEMONIK_ODBIORCY!='OK' ,c(1,2,3,10,13,20)], sum )
colnames(zia)[7]<-'BLEDY'

zia= transform(zia, RATIO = 1-zia$BLEDY/zia$BLEDY.y)
zia$TRESHOLD <- ifelse(zia$RATIO>=0.8, ifelse(zia$RATIO>=0.95, "super", "akceptowalne"), "zle")



#####
###Rserve
#https://stackoverflow.com/questions/26225066/how-can-i-shut-down-rserve-gracefully
library(Rserve)
library(RSclient)
run.Rserve(port = 6311, debug = TRUE)
rsc <- RSconnect(port = 6311)
RSshutdown(rsc)

#hive

library(RJDBC)

#Load Hive JDBC driver
hivedrv <- JDBC("org.apache.hadoop.hive.jdbc.HiveDriver",
                c(list.files("/home/amar/hadoop/hadoop",pattern="jar$",full.names=T),
                  list.files("/home/amar/hadoop/hive/lib",pattern="jar$",full.names=T)))

#Connect to Hive service
hivecon <- dbConnect(hivedrv, "jdbc:hive://ip:port/default")
query = "select * from mytable LIMIT 10"
hres <- dbGetQuery(hivecon, query)

.jinit()
## use this instead to debug any Kerberos issues:
## .jinit(,"-Dsun.security.krb5.debug=true")
.jaddClassPath(Sys.glob(strsplit(system("hadoop classpath",int=T),":",T)[[1]]))
conf = .jnew("org.apache.hadoop.conf.Configuration")
conf$set("hadoop.security.authentication", "Kerberos")
ugi = J("org.apache.hadoop.security.UserGroupInformation")
ugi$setConfiguration(conf)
ugi$loginUserFromKeytab("lukasz.janiszewski@bgzbnpparibas.pl",".keytab")
.jaddClassPath(Sys.glob("C:\\Oracle\\product\\12.1.0\\client_1\\jdbc\\lib\\*.jar"))
library(RJDBC)

j <- JDBC("org.apache.hive.jdbc.HiveDriver"
          , classPath="C:\\Oracle\\product\\12.1.0\\client_1\\jdbc\\lib\\HiveJDBC41.jar")

j=JDBC("org.apache.hive.jdbc.HiveDriver")
c=dbConnect(j, "jdbc:hive2://hdp-tstnn01.fortisbank.com.pl:10000/default;principal=hive/_HOST@TST.HADOOP.BANK.PL")




hivedrv <- JDBC("org.apache.hive.jdbc.HiveDriver",
                c(list.files("C:\\Oracle\\product\\12.1.0\\client_1\\jdbc\\lib\\",pattern="jar$",full.names=T),
                  list.files("C:\\Oracle\\product\\12.1.0\\client_1\\jdbc\\lib\\",pattern="jar$",full.names=T)))


library(RODBC)

dbconnection <- odbcConnect("pi;trusted_connection=true")

omr <- sqlQuery(dbconnection, "select * from PI_DANE.SM_TRANSLACJE_BUFOR_WAL")

odbcClose(dbconnection)

odbcClose(dbhandle)

omrdb<-omr[ omr$OKRES_DO>'3999/01/01', c("KOLUMNA","WARTOSC","WARUNEK", "KOLEJNOSC", "KOLEJNOSC_GRUP")]

sqlQuery(dbconnection, "Drop table bjd.dbo.SM_TRANSLACJE_BUFOR_WAL")

dbconnection <- odbcConnect("bjd")
dbhandle <-odbcDriverConnect('driver={SQL Server};server=sqlsrv,1433;database=bjd;trusted_connection=true')

toSQL = data.frame(omrdb)

columnTypes <- list("WARUNEK"="varchar(1000)", "CUT_WAR"="varchar(500)")

sqlSave(dbhandle, omrdb, tablename = 'omr.SM_TRANSLACJE_BUFOR_WAL', varTypes= columnTypes #c("CUT_WAR"="varchar(500)")
        ,rownames = F, addPK=F)

#sqlUpdate(dbhandle, omrdb, 'dbo.SM_TRANSLACJE_BUFOR_WAL')

#sqlDrop(dbconnection, 'bjd.dbo.SM_TRANSLACJE_BUFOR_WAL')

omrdb$KOLUMNA <- as.character(omrdb$KOLUMNA)

omrdb$WARTOSC <- as.character(omrdb$WARTOSC)

omrdb$WARUNEK <- as.character(omrdb$WARUNEK)

omrdb$KOLEJNOSC <- as.character(omrdb$KOLEJNOSC)

omrdb$KOLEJNOSC_GRUP <- as.character(omrdb$KOLEJNOSC_GRUP)


sqlTables(dbconnection)

library(readxl)
library(sqldf)
library(odbc)

dbWriteTable(conn = dbconnection, 
             name = "bjd.dbo.SM_TRANSLACJE_BUFOR_WAL", 
             value = omrdb)



omrdb[nchar(as.character( omrdb$WARUNEK))>255, "KOLEJNOSC_GRUP"]


omrdb[omrdb$KOLEJNOSC_GRUP==490,"WARUNEK"][1]

gsub("*/.*", " ",omrdb$WARUNEK[45])

omrdb$CUT_WAR<-gsub("substr", "SUBSTRING",gsub("=.", " is null ",gsub("&IP_DATE"," @REPO_DATE ",gsub("&IP_DATE.", " @REPO_DATE ",gsub("^=", " <> ",gsub(" ne ", " <> ",gsub(" ne''", " is not null ", gsub("=.'' ", " is null ",gsub(" ne . ", " is not null ",gsub("ne '' ", " is not null ",gsub("= .", " is null ", gsub("^= .", " is not null ", gsub("^=.", " is not null ",gsub("^='' ", " is not null ",gsub("/\\*.*?\\*/", " ",omrdb$WARUNEK), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE),fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE)

gsub(" ne .  ", " is not null ", omrdb$WARUNEK[460], fixed=TRUE)

write.csv(omrdb, "omr.csv")

library("xlsx")

write.xlsx(omrdb, "omr.xlsx", sheetName = "Sheet1", 
           col.names = TRUE, append = FALSE)

### rf

library(rJava)

# Load RJDBC library
library(RJDBC)

# Create connection driver and open connection
jdbcDriver <- JDBC(driverClass="oracle.jdbc.OracleDriver", classPath="C:\\Oracle\\product\\12.1.0\\client_1\\jdbc\\lib\\ojdbc7.jar")
jdbcConnection <- 
  dbConnect(jdbcDriver, "jdbc:oracle:thin:@dmpoc-tst04:1521/IDQPOC", "service_idq_tst", rstudioapi::askForPassword("Database password"))

currTableSQL<-paste("select * from SERVICE_IDQ_TST.V_DASHBOARD_DG_RAP ",sep="")

oracl <- dbGetQuery(jdbcConnection, currTableSQL)

library(RODBC)
dbhandle <-odbcDriverConnect('driver={SQL Server};server=sqlsrv,1433;database=bjd;trusted_connection=true')

sqlQuery(dbhandle,'drop table bjd.omr.V_DASHBOARD_DG_RAP')

sqlSave(dbhandle, oracl, tablename = 'omr.V_DASHBOARD_DG_RAP'#, varTypes= columnTypes #c("CUT_WAR"="varchar(500)")
        ,rownames = F, addPK=F)


##############srs

db <- read_excel("code_srs.xlsx",1,col_names = TRUE)

db$SQL_ALG<-gsub("substr", "SUBSTRING",gsub("=.", " is null ",gsub("&IP_DATE"," @REPO_DATE ",gsub("&IP_DATE.", " @REPO_DATE ",gsub("^=", " <> ",gsub(" ne ", " <> ",gsub(" ne''", " is not null ", gsub("=.'' ", " is null ",gsub(" ne . ", " is not null ",gsub("ne '' ", " is not null ",gsub("= .", " is null ", gsub("^= .", " is not null ", gsub("^=.", " is not null ",gsub("^='' ", " is not null ",gsub("/\\*.*?\\*/", " ",db$Algorithm), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE),fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE)
db$SQL_FILTR<-gsub("substr", "SUBSTRING",gsub("=.", " is null ",gsub("&IP_DATE"," @REPO_DATE ",gsub("&IP_DATE.", " @REPO_DATE ",gsub("^=", " <> ",gsub(" ne ", " <> ",gsub(" ne''", " is not null ", gsub("=.'' ", " is null ",gsub(" ne . ", " is not null ",gsub("ne '' ", " is not null ",gsub("= .", " is null ", gsub("^= .", " is not null ", gsub("^=.", " is not null ",gsub("^='' ", " is not null ",gsub("/\\*.*?\\*/", " ",db$Filtr), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE),fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE), fixed=TRUE)


write.xlsx(db, "srs_sql.xlsx", sheetName = "Sheet1", 
           col.names = TRUE, append = FALSE)


