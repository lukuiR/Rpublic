email='"us:addressSMTP[1]"">
	<item xsi:type=""bus:addressSMTP"">zzjd@bgzbnpparibas.pl</item>
</value>
toAddress;deliveryOptionEnum;deliveryOptionAddressSMTPArray;162;<value xsi:type=""SOAP-ENC:Array"" SOAP-ENC:arrayType=""bus:addressSMTP[1]"">
<item xsi:type=""bus:addressSMTP"">radoslaw.borusiewicz@bnpparibas.pl</item>
</value>
subject;deliveryOptionEnum;deliveryOptionString;88;<value xsi:type=""xsd:string"">[Raport Cognos] Ksiegowania ZRP - opcje ITA i ZPA</value>
emailAsAttachment;runOptionEnum;runOptionBoolean;44;<value xsi:type=""xsd:boolean"">true</value>
"
'

email='"us:addressSMTP[1]"">
	<item xsi:type=""bus:addressSMTP"">MATURA Wieslaw (MATURA)</item>
</value>
subject;deliveryOptionEnum;deliveryOptionString;51;<value xsi:type=""xsd:string"">Report: Rap1</value>
to;deliveryOptionEnum;deliveryOptionSearchPathMultipleObjectArray;219;<value xsi:type=""SOAP-ENC:Array"" SOAP-ENC:arrayType=""bus:searchPathMultipleObject[1]"">
<item xsi:type=""bus:searchPathMultipleObject"">CAMID(&quot;AD-krak-dc1:u:276fa8aafb7d434a8fce4e7648150b79&quot;)</item>
</value>
emailAsAttachment;runOptionEnum;runOptionBoolean;44;<value xsi:type=""xsd:boolean"">true</value>
"
'


email %>%html_nodes('bus:addressSMTP') %>% html_text()
gsub('bus:addressSMTP"">',"",email)


gsub('<','',gsub('>','',unlist(regmatches(email, gregexpr('>\\S+@\\S+<', email)))))

gregexpr('>\\S+<', email)


gsub('</item>','',gsub('bus:addressSMTP"">','',unlist(regmatches(email, gregexpr('bus:addressSMTP"">\\S* \\S* (\\S*)</item>', email)))))


ar <- read_excel('3zzjdRap.xlsx',1,col_names = TRUE)

gsub('<','',gsub('>','',unlist(regmatches(ar$X__4, gregexpr('>\\S+@\\S+<', ar$X__4)))))

unlist(regmatches(ar$X__4[25], gregexpr('bus:addressSMTP\\S* \\S* (\\S*)</item>', ar$X__4[25])))

gsub('</item>','',gsub('bus:addressSMTP\">','',unlist(regmatches(ar$X__4, gregexpr('bus:addressSMTP\\S* \\S* (\\S*)</item>', ar$X__4)))))

ar$email= gsub('<','',gsub('>','',unlist(regmatches(ar$X__4, gregexpr('>\\S+@\\S+<', ar$X__4)))))
ar$nameemail=0

ar$email2=0
ar$email1=0
ar$email3=0
ar$email4=0
ar$email5=0
ar$email6=0
ar$email7=0
ar$email8=0
ar$email9=0
ar$email10=0


for (i in 1:dim(ar)[1]) {
  if(length((unlist(regmatches(ar$X__4[i], gregexpr('xsd:string\\S*[ ]?\\S*[ ]?\\S*[ ]?\\S*[ ]?[:xdigit:]*[ ]?[:punct:]*[ ]?\\S*[ ]?[:xdigit:]*[ ]?\\S*[ ]?\\S*[ ]?[:punct:]*[ ]?\\S*[ ]?[:punct:]*[ ]?\\S*[:punct:]*\\S*', ar$X__4[i])))))>0){
    
  ar$nameemail[i]= gsub('xsd:string','', unlist(regmatches(ar$X__4[i], gregexpr('xsd:string\\S*[ ]?\\S*[ ]?\\S*[ ]?\\S*[ ]?[:xdigit:]*[ ]?[:punct:]*[ ]?\\S*[ ]?[:xdigit:]*[ ]?\\S*[ ]?\\S*[ ]?[:punct:]*[ ]?\\S*[ ]?[:punct:]*[ ]?\\S*[:punct:]*\\S*', ar$X__4[i]))))
  }
  ar$email1[i]= gsub('<','',gsub('>','',unlist(regmatches(ar$X__4[i], gregexpr('>\\S+@\\S+<', ar$X__4[i])))))[1]
  ar$email2[i]= gsub('<','',gsub('>','',unlist(regmatches(ar$X__4[i], gregexpr('>\\S+@\\S+<', ar$X__4[i])))))[2]
  ar$email3[i]= gsub('<','',gsub('>','',unlist(regmatches(ar$X__4[i], gregexpr('>\\S+@\\S+<', ar$X__4[i])))))[3]
  ar$email4[i]= gsub('<','',gsub('>','',unlist(regmatches(ar$X__4[i], gregexpr('>\\S+@\\S+<', ar$X__4[i])))))[4]
  ar$email5[i]= gsub('<','',gsub('>','',unlist(regmatches(ar$X__4[i], gregexpr('>\\S+@\\S+<', ar$X__4[i])))))[5]
  ar$email6[i]= gsub('<','',gsub('>','',unlist(regmatches(ar$X__4[i], gregexpr('>\\S+@\\S+<', ar$X__4[i])))))[6]
  ar$email7[i]= gsub('<','',gsub('>','',unlist(regmatches(ar$X__4[i], gregexpr('>\\S+@\\S+<', ar$X__4[i])))))[7]
  ar$email8[i]= gsub('<','',gsub('>','',unlist(regmatches(ar$X__4[i], gregexpr('>\\S+@\\S+<', ar$X__4[i])))))[8]
  ar$email9[i]= gsub('<','',gsub('>','',unlist(regmatches(ar$X__4[i], gregexpr('>\\S+@\\S+<', ar$X__4[i])))))[9]
  ar$email10[i]= list(gsub('<','',gsub('>','',unlist(regmatches(ar$X__4[i], gregexpr('>\\S+@\\S+<', ar$X__4[i]))))))
  
  ar$email[i]= list(gsub('</item>','',gsub('bus:addressSMTP\">','',unlist(regmatches(ar$X__4[i], gregexpr('bus:addressSMTP\\S* \\S* (\\S*)</item>', ar$X__4[i]))))))
  
}

ar$email10=as.character(ar$email10)
ar$email=as.character(ar$email)

write.csv2(ar,file='newrap.csv')



for (i in 1:dim(ar)[1]) {
  
  gsub('<','',gsub('>','',unlist(regmatches(ar$X__4[i], gregexpr('>\\S+@\\S+<', ar$X__4[i])))))[1]
  unlist(regmatches(ar$X__4[i], gregexpr('xsd:string\\S*[ ]?\\S*[ ]?\\S*[ ]?\\S*[ ]?[:xdigit:]*[ ]?[:punct:]*[ ]?\\S*[ ]?[:xdigit:]*[ ]?\\S*[ ]?\\S*[ ]?[:punct:]*[ ]?\\S*[ ]?[:punct:]*[ ]?\\S*[:punct:]*\\S*', ar$X__4[i])))
}


ar <- read_excel('2zzjdRap.xlsx',6,col_names = TRUE)

gsub('<','',gsub('>','',unlist(regmatches(ar$X__4, gregexpr('>\\S+@\\S+<', ar$X__4)))))

unlist(regmatches(ar$X__4[25], gregexpr('bus:addressSMTP\\S* \\S* (\\S*)</item>', ar$X__4[25])))

gsub('</item>','',gsub('bus:addressSMTP\">','',unlist(regmatches(ar$X__4, gregexpr('"xsd:string"">\\S* \\S* </value>', ar$X__4)))))

<value xsi:type=""xsd:string"">[Raport Cognos] Ksiegowania ZRP - opcje ITA i ZPA</value>
  
  unlist(regmatches(ar$X__4,
                    
                    gregexpr('</value>', ar$X__4)
                    
                    ))

unlist(regmatches(ar$X__4, gregexpr('xsd:string\\S*', ar$X__4)))


unlist(regmatches(ar$X__4, gregexpr('xsd:string\\S*[ ]?\\S*[ ]?\\S*[ ]?\\S*[ ]?[:xdigit:]*[ ]?[:punct:]*[ ]?\\S*[ ]?[:xdigit:]*[ ]?\\S*[ ]?\\S*[ ]?[:punct:]*[ ]?\\S*[ ]?[:punct:]*[ ]?\\S*[:punct:]*\\S*', ar$X__4)))

ar1=data.frame(ar)

write.csv2(ar[,c(1,2,3,4,5,6,7,8,12,13,14,15,16,17,18:22)],file='ar.csv')

write.csv2()

head(ar[,-8])

colnames(ar)

save(ar, file = "mobyPOS.Rdata")

ar1<-load("mobyPOS.Rdata")
