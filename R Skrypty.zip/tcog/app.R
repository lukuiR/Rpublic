#https://rviews.rstudio.com/2017/09/20/dashboards-with-r-and-databases/
#https://gist.github.com/mikolajolszewski/a002243531d40c72080a733910a9bda7


library(shiny)
library(shinydashboard)
library(dplyr)
library(dbplyr)
library(purrr)
library(highcharter)
library(DT)
library(htmltools)
library(plotly)

# Use purrr's split() and map() function to create the list
# needed to display the name of the airline but pass its
# Carrier code as the value


ui <- dashboardPage(skin = "green",
  dashboardHeader(title = "BGZ BNP" #,titleWidth = 200
                  ),
  dashboardSidebar(
    
    selectInput(
      inputId = "typ",
      label = "Typ:", 
      choices = unique(alg$typ), 
      multiple = TRUE),
    selectInput(
      inputId = "kod",
      label = "Kod:", 
      choices = unique(met_kon$KOD_OBSZARU), 
      multiple = TRUE),
    selectInput(
      inputId = "waga",
      label = "Waga:", 
      choices = unique(met_kon$WAGA_KONTROLI), 
      multiple = TRUE),
    selectInput(
      inputId = "jed",
      label = "Jednostka:", 
      choices = unique(met_kon$JEDNOSTKA_ZGLASZAJACA), 
      multiple = TRUE),
    selectInput(
      inputId = "mail",
      label = "Mnemonik:", 
      choices = unique(o_grp$MNEMONIK_ODBIORCY), 
      multiple = TRUE),
    sidebarMenu(
      selectInput(
        "month",
        "Miesiac:", 
        list(
          "All Year" = 99,
          "January" = '01',
          "February" = '02',
          "March" = '03',
          "April" = '04',
          "May" = '05',
          "June" = '06',
          "July" = '07',
          "August" = '08',
          "September" = '09',
          "October" = '10',
          "November" = '11',
          "December" = '12'
        ) , 
        selected =  "All Year", 
        selectize = FALSE),
      actionLink("remove", "Wyczysc dodatkowe karty")
    )
  ),
  dashboardBody(      
    tabsetPanel(id = "tabs",   
                tabPanel(includeCSS("styles1.css"),
                  title = "ZZJD Dashboard",icon = icon("glyphicon glyphicon-saved",lib ="glyphicon"),
                  value = "page1",
                  fluidRow(
                    valueBoxOutput("kpi1"),
                    valueBoxOutput("kpi2"),
                    valueBoxOutput("percent_delayed")
                  ),
                  fluidRow(
                    valueBoxOutput("kpi4"),
                    valueBoxOutput("kpi5"),
                    valueBoxOutput("kpi6")
                  ),
                  fluidRow(h2('Treshold na grupe'),
                    valueBoxOutput("kpi7"),
                    valueBoxOutput("kpi8"),
                    valueBoxOutput("kpi9")
                  ),
                  fluidRow(h2('Treshold na id'),
                    valueBoxOutput("kpi17"),
                    valueBoxOutput("kpi18"),
                    valueBoxOutput("kpi19")
                  ),
                  fluidRow(
                    valueBoxOutput("kpi10"),
                    valueBoxOutput("kpi11")
                    ),
                    fluidRow(
                      plotlyOutput("pguage"),
                      valueBoxOutput("percent_delayed4")
                    
                  ),
                  fluidRow(
                    column(width = 7,
                           p(textOutput("monthly")),
                           highchartOutput("group_totals")),
                    column(width = 5,
                           p("Click on an airport in the plot to see the details"),
                           highchartOutput("top_airports"))
                  )
                ),
                tabPanel("Plot", icon = icon("line-chart"),plotlyOutput("plot"),plotlyOutput("plot2")
                         
                         )
    )
  )
)




server <- function(input, output, session) { 
  
  tab_list <- NULL
  
  o_grp<-o_grp[complete.cases(o_grp),]
  # Preparing the data by pre-joining flights to other
  # tables and doing some name clean-up
  # db_flights <- flights %>%
  #   left_join(airlines, by = "carrier") %>%
  #   rename(airline = name) %>%
  #   left_join(airports, by = c("origin" = "faa")) %>%
  #   rename(origin_name = name) %>%
  #   select(-lat, -lon, -alt, -tz, -dst) %>%
  #   left_join(airports, by = c("dest" = "faa")) %>%
  #   rename(dest_name = name) 
  
  output$monthly <- renderText({
    if(input$month == "99")"Click on a month in the plot to see the daily counts"
  })
  
  output$kpi1 <- renderValueBox({
    # The following code runs inside the database
    
    result <- z2
    if(is.null(input$waga) != TRUE) result <- filter(result, WAGA_KONTROLI %in% input$waga)
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, JEDNOSTKA_ZGLASZAJACA %in% input$jed)
    if(is.null(input$kod) != TRUE) result <- filter(result, KOD_OBSZARU %in% input$kod)
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)
    
    result <- result %>%
      tally() %>%
      pull() %>% 
      as.integer()
    
    valueBox(value = prettyNum(result, big.mark = ","),
             subtitle = "Number of data")
  })
  
  
  output$kpi2 <- renderValueBox({
    # The following code runs inside the database
    
    result <- z2
    if(is.null(input$waga) != TRUE) result <- filter(result, WAGA_KONTROLI %in% input$waga)
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, JEDNOSTKA_ZGLASZAJACA %in% input$jed)
    if(is.null(input$kod) != TRUE) result <- filter(result, KOD_OBSZARU %in% input$kod)
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)
    
    valueBox(
      formatC(length(unique(result[result$DATA=='2018-02-28','GRUPA_ALGORYTMU'])), format="d", big.mark=','),width=
        ,paste('ilosc kontroli lm')
      ,icon = icon("glyphicon glyphicon-remove-sign",lib='glyphicon')
      ,color = "red")
    
  })
  
  
  output$percent_delayed <- renderValueBox({
    
    result <- z2
    if(is.null(input$waga) != TRUE) result <- filter(result, WAGA_KONTROLI %in% input$waga)
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, JEDNOSTKA_ZGLASZAJACA %in% input$jed)
    if(is.null(input$kod) != TRUE) result <- filter(result, KOD_OBSZARU %in% input$kod)
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)

    valueBox(
      formatC(sum(result[as.character(result$DATA)==max(as.character(result$DATA)) & result$MNEMONIK_ODBIORCY!='OK',"BLEDY.x"]), format="d", big.mark=','),width=
        ,paste('Bledy')
      ,icon = icon("stats",lib='glyphicon')
      ,color = "purple")
    
  })
  
  #######new kpi
  
  output$kpi4 <- renderValueBox({
    # The following code runs inside the database
    
    result <- z2%>%
      filter(MNEMONIK_ODBIORCY != 'OK')
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)
    
    valueBox(
      formatC(dim(unique(result[result$DATA=='2018-02-28' & result$TRESHOLD=='super',c('GRUPA_ALGORYTMU','MNEMONIK_ODBIORCY')]))[1], format="d", big.mark=','),width=
        ,paste('super')
      ,icon = icon("stats",lib='glyphicon')
      ,color = "green")
  })
  
  
  output$kpi5 <- renderValueBox({
    result <- z2%>%
      filter(MNEMONIK_ODBIORCY != 'OK')
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    
    
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)

    valueBox(
      formatC(dim(unique(result[result$DATA=='2018-02-28' & result$TRESHOLD=='akceptowalne',c('GRUPA_ALGORYTMU','MNEMONIK_ODBIORCY')]))[1], format="d", big.mark=','),width=
        ,paste('akceptowalne')
      ,icon = icon("glyphicon glyphicon-remove-sign",lib='glyphicon')
      ,color = "yellow")
    
  })
  
  
  output$kpi6 <- renderValueBox({
    result <- z2%>%
      filter(MNEMONIK_ODBIORCY != 'OK')
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    # The following code runs inside the database
    
    valueBox(
      formatC(dim(unique(result[result$DATA=='2018-02-28' & result$TRESHOLD=='zle',c('GRUPA_ALGORYTMU','MNEMONIK_ODBIORCY')]))[1], format="d", big.mark=','),width=
        ,paste('zle')
      ,icon = icon("glyphicon glyphicon-wrench",lib='glyphicon')
      ,color = "red")
    
  })
  #######new kpi row2

  output$kpi10 <- renderValueBox({
    # The following code runs inside the database
    
    result <- za
    if(is.null(input$waga) != TRUE) result <- filter(result, WAGA_KONTROLI %in% input$waga)
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, JEDNOSTKA_ZGLASZAJACA %in% input$jed)
    if(is.null(input$kod) != TRUE) result <- filter(result, KOD_OBSZARU %in% input$kod)
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)
    
    valueBox(
      formatC(length(unique(result[result$DATA=='2018-02-28','GRUPA_ALGORYTMU'])), format="d", big.mark=','),width=
        ,paste('ilosc kontroli lm')
      ,icon = icon("glyphicon glyphicon-remove-sign",lib='glyphicon')
      ,color = "red")
    
  })
  
  output$kpi7 <- renderValueBox({
    # The following code runs inside the database
    
    result <- za
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)
    
    valueBox(
      formatC(length(unique(result[result$DATA=='2018-02-28' & result$TRESHOLD=='super','GRUPA_ALGORYTMU'])), format="d", big.mark=','),width=
        ,paste('super lm')
      ,icon = icon("stats",lib='glyphicon')
      ,color = "green")
  })
  
  output$kpi8 <- renderValueBox({
    result <- za
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    
    
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)
    
    valueBox(
      formatC(length(unique(result[result$DATA=='2018-02-28' & result$TRESHOLD=='akceptowalne','GRUPA_ALGORYTMU'])), format="d", big.mark=','),width=
        ,paste('akceptowalne lm')
      ,icon = icon("glyphicon glyphicon-remove-sign",lib='glyphicon')
      ,color = "yellow")
    
  })
  
  output$kpi9 <- renderValueBox({
    result <- za
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    # The following code runs inside the database
    
    valueBox(
      formatC(length(unique(result[result$DATA=='2018-02-28' & result$TRESHOLD=='zle','GRUPA_ALGORYTMU'])), format="d", big.mark=','),width=
        ,paste('zle lm')
      ,icon = icon("glyphicon glyphicon-wrench",lib='glyphicon')
      ,color = "red")
    
  })
  
  ####id alg
  output$kpi17 <- renderValueBox({
    # The following code runs inside the database
    
    result <- zia
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)
    
    valueBox(
      formatC(length(unique(result[result$DATA=='2018-02-28' & result$TRESHOLD=='super','ID_ALGORYTMU'])), format="d", big.mark=','),width=
        ,paste('super id lm')
      ,icon = icon("stats",lib='glyphicon')
      ,color = "green")
  })
 
  output$kpi18 <- renderValueBox({
    result <- zia
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    
    
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)
    
    valueBox(
      formatC(length(unique(result[result$DATA=='2018-02-28' & result$TRESHOLD=='akceptowalne','ID_ALGORYTMU'])), format="d", big.mark=','),width=
        ,paste('akceptowalne id lm')
      ,icon = icon("glyphicon glyphicon-remove-sign",lib='glyphicon')
      ,color = "yellow")
    
  })
 
  output$kpi19 <- renderValueBox({
    result <- zia
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    # The following code runs inside the database
    
    valueBox(
      formatC(length(unique(result[result$DATA=='2018-02-28' & result$TRESHOLD=='zle','ID_ALGORYTMU'])), format="d", big.mark=','),width=
        ,paste('zle id lm')
      ,icon = icon("glyphicon glyphicon-wrench",lib='glyphicon')
      ,color = "red")
    
  })
  
  output$kpi11 <- renderValueBox({
    # The following code runs inside the database
    
    result <- zia
    if(is.null(input$waga) != TRUE) result <- filter(result, WAGA_KONTROLI %in% input$waga)
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, JEDNOSTKA_ZGLASZAJACA %in% input$jed)
    if(is.null(input$kod) != TRUE) result <- filter(result, KOD_OBSZARU %in% input$kod)
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)
    
    valueBox(
      formatC(length(unique(result[result$DATA=='2018-02-28','ID_ALGORYTMU'])), format="d", big.mark=','),width=
        ,paste('ilosc kontroli id lm')
      ,icon = icon("glyphicon glyphicon-remove-sign",lib='glyphicon')
      ,color = "red")
    
  })
  
  ################
  output$total_flights3 <- renderValueBox({
    # The following code runs inside the database
    
    result <- o_grp
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)
    
    valueBox(
      paste(round(sum(result[result$MNEMONIK_ODBIORCY != 'OK' & substr(as.character(result$DATA),1,7)==max(substr(as.character(result$DATA),1,7)),"BLEDY"])/sum(result[result$MNEMONIK_ODBIORCY == 'OK' & substr(as.character(result$DATA),1,7)==max(substr(as.character(result$DATA),1,7)),"BLEDY"]),6)*100,"%"),width=
        ,paste('Odstetek BĹ‚Ä™dĂłw')
      ,icon = icon("stats",lib='glyphicon')
      ,color = "purple")
  })
 
  output$per_day3 <- renderValueBox({
    result <- o_grp%>%
      filter(MNEMONIK_ODBIORCY != 'OK')
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    
    
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month)
    
    valueBox(
     paste( round(sum(result[substr(as.character(result$DATA),1,7)==max(substr(as.character(result$DATA),1,7)),"BLEDY_NOWE"])/sum(result[substr(as.character(result$DATA),1,7)==max(substr(as.character(result$DATA),1,7)),"BLEDY"]), 6)*100,"%"),width=
        ,paste('Bledy Nowe/Bledy')
      ,icon = icon("glyphicon glyphicon-remove-sign",lib='glyphicon')
      ,color = "red")
    
  })
  
  output$percent_delayed3 <- renderValueBox({
    result <- o_grp%>%
      filter(MNEMONIK_ODBIORCY != 'OK')
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    # The following code runs inside the database
    
    valueBox(
      paste(round(sum(result[substr(as.character(result$DATA),1,7)==max(substr(as.character(result$DATA),1,7)),"BLEDY_POPRAWIONE"])/sum(result[substr(as.character(result$DATA),1,7)==max(substr(as.character(result$DATA),1,7)),"BLEDY"]), 6)*100,"%")
        ,paste('Bledy Poprawione/Bledy')
      ,icon = icon("glyphicon glyphicon-wrench",lib='glyphicon')
      ,color = "green")
    
  }) 
  
  output$percent_delayed4 <- renderValueBox({
    result <- o_grp%>%
      filter(MNEMONIK_ODBIORCY != 'OK')
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    # The following code runs inside the database
    
    valueBox(
      paste(round(sum(result[substr(as.character(result$DATA),1,7)==max(substr(as.character(result$DATA),1,7)),"BLEDY_POPRAWIONE"])/sum(result[substr(as.character(result$DATA),1,7)==max(substr(as.character(result$DATA),1,7)),"BLEDY_NOWE"]), 6)*100,"%")
        ,paste('BĹ‚Ä™dy Poprawione/BĹ‚Ä™dy Nowe')
      ,icon = icon("glyphicon glyphicon-wrench",lib='glyphicon')
      ,color = "green")
    
  })
  # Events in Highcharts can be tracked using a JavaScript. For data points in a plot, the 
  # event.point.category returns the value that is used for an additional filter, in this case
  # the month that was clicked on.  A paired observeEvent() command is activated when
  # this java script is executed
  js_click_line <- JS("function(event) {Shiny.onInputChange('line_clicked', [event.point.category]);}")
  
  output$group_totals <- renderHighchart({
    result <- o_grp
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    if(input$month != 99) {
      result1 <-filter(result, substr(DATA,6,7) == input$month) %>%
        group_by(DATA) %>%
        tally(BLEDY_NOWE) 
      group_name <- "Daily"
      result2 <-filter(result, substr(DATA,6,7) == input$month) %>%
        group_by(DATA) %>%
        tally(BLEDY_POPRAWIONE) 
      group_name <- "Daily"
      result3 <-filter(result, substr(DATA,6,7) == input$month) %>%
        group_by(DATA) %>%
        tally(BLEDY) 
      group_name <- "Daily"
      result4 <-filter(result, substr(DATA,6,7) == input$month) %>%
        group_by(DATA) %>%
        tally(BLEDY_NOWE_POPR) 
      group_name <- "Daily"
    } else {
      result1 <- result %>%
        group_by(substr(DATA,1,7)) %>%
        tally(BLEDY_NOWE)     
      group_name <- "Monthly"
      result2 <- result %>%
        group_by(substr(DATA,1,7)) %>%
        tally(BLEDY_POPRAWIONE)     
      group_name <- "Monthly"
      result3 <- result %>%filter(MNEMONIK_ODBIORCY!="OK")%>%
        group_by(substr(DATA,1,7)) %>%
        tally(BLEDY)     
      group_name <- "Monthly"
      result4 <- result %>%filter(MNEMONIK_ODBIORCY!="OK")%>%
        group_by(substr(DATA,1,7)) %>%
        tally(BLEDY_NOWE_POPR)     
      group_name <- "Monthly"
    } 
    
    highchart() %>% 
           hc_chart(type = "line") %>% 
           hc_title(text = "Wykres bĹ‚Ä™dĂłw") %>% 
           hc_xAxis(categories = result1$`substr(DATA, 1, 7)`) %>% 
          hc_add_series(data = result1$n[complete.cases(result1)],name = paste("iloĹ›Ä‡ bĹ‚Ä™dĂłw nowych"),
        events = list(click = js_click_line))%>%
    hc_add_series(data = result2$n[complete.cases(result2)],name = paste("iloĹ›Ä‡ bĹ‚Ä™dĂłw poprawione"),
                  events = list(click = js_click_line))%>%
      hc_add_series(data = result3$n[complete.cases(result3)],name = paste("iloĹ›Ä‡ bĹ‚Ä™dĂłw"),
                    events = list(click = js_click_line))%>%
      hc_add_series(data = result4$n[complete.cases(result4)],name = paste("iloĹ›Ä‡ bĹ‚Ä™dĂłw nowych pop."),
                    events = list(click = js_click_line))
    
    
  })
  
  # Tracks the JavaScript event created by `js_click_line`
  observeEvent(input$line_clicked != "",
               if(input$month == 99)
                 updateSelectInput(session, "month", selected = substr(input$line_clicked,6,7)),
               ignoreInit = TRUE)
  
  js_bar_clicked <- JS("function(event) {Shiny.onInputChange('bar_clicked', [event.point.category]);}")
  
  output$top_airports <- renderHighchart({
    # The following code runs inside the database
    result <- o_grp
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    
    if(input$month != 99) result <- filter(result, substr(DATA,6,7) == input$month) 
    
    result <- result %>%
      group_by(GRUPA_ALGORYTMU) %>%
      tally(BLEDY) %>%
      arrange(desc(n)) %>%
      collect() %>%
      head(10)
    
    highchart() %>%
      hc_add_series(
        data = result$n, 
        type = "bar",
        name = paste("GRUPA ALGORYTMU"),
        events = list(click = js_bar_clicked)) %>%
      hc_xAxis(
        categories = result$GRUPA_ALGORYTMU,
        tickmarkPlacement="on")
    
    
  })
  
  #####plot plane
  
  output$pguage <- renderPlotly({
    result <- o_grp
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    
    plot_ly(
      type = "pie",
      values = c(40, 10, 10, 10, 10, 10, 10),
      labels = c("-", "0", "20", "40", "60", "80", "100"),
      rotation = 108,
      direction = "clockwise",
      hole = 0.4,
      textinfo = "label",
      textposition = "outside",
      hoverinfo = "none",
      domain = list(x = c(0, 0.48), y = c(0, 1)),
      marker = list(colors = c('rgb(255, 255, 255)', 'rgb(255, 255, 255)', 'rgb(255, 255, 255)', 'rgb(255, 255, 255)', 'rgb(255, 255, 255)', 'rgb(255, 255, 255)', 'rgb(255, 255, 255)')),
      showlegend = FALSE
    )%>%
      add_trace(
      type = "pie",
      values = c(50, 10, 10, 10, 10, 10),
      labels = c("Error Log Level Meter", "Debug", "Info", "Warn", "Error", "Fatal"),
      rotation = 90,
      direction = "clockwise",
      hole = 0.3,
      textinfo = "label",
      textposition = "inside",
      hoverinfo = "none",
      domain = list(x = c(0, 0.48), y = c(0, 1)),
      marker = list(colors = c('rgb(255, 255, 255)', 'rgb(232,226,202)', 'rgb(226,210,172)', 'rgb(223,189,139)', 'rgb(223,162,103)', 'rgb(226,126,64)')),
      showlegend= FALSE
    )%>%
      layout(
        shapes = list(
          list(
            type = 'path',
            path = 'M 0.235 0.5 L 0.235 0.62 L 0.245 0.5 Z',
            xref = 'paper',
            yref = 'paper',
            fillcolor = 'rgba(144, 160, 101, 0.5)'
          )
        ),
        xaxis = list(
          showticklabels = FALSE,
          autotick = FALSE,
          showgrid = FALSE,
          zeroline = FALSE),
        yaxis = list(
          showticklabels = FALSE,
          autotick = FALSE,
          showgrid = FALSE,
          zeroline = FALSE),
        annotations = list(
          xref = 'paper',
          yref = 'paper',
          x = 0.23,
          y = 0.45,
          showarrow = FALSE,
          text = '50')
      )
    
    
  })
  
  
  output$plot <- renderPlotly({
    result <- o_grp
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    
    plot_ly(result,labels = ~GRUPA_ALGORYTMU, values = ~BLEDY, type = "pie",textposition = "inside"
    )%>%
      layout(title = 'UdziaĹ‚ % Grup AlgorytmĂłw',
             xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
             yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))
    
  })
  
  
  output$plot2 <- renderPlotly({
    result <- o_grp
    if(is.null(input$waga) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) result <- filter(result, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) result <- filter(result, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    result<-result%>% group_by(DATA)%>% summarise(ratio=sum(BLEDY_POPRAWIONE)/sum(BLEDY_NOWE))
    
    plot_ly(result, x=~DATA, y=~ratio, type ="scatter",mode = "lines"
    )%>% add_trace(x=~DATA,y=1)%>%
      layout(yaxis = list(tickformat = "%"), margin = list(b = 80), xaxis = list(tickangle = 45))
    
  })
  
  

  #####
  mtSummarised1 <- reactive({
    
    details <- o_grp %>%
      filter(GRUPA_ALGORYTMU == input$bar_clicked[1])
    details <- details %>% 
      mutate(month = month.name[as.integer(substr(DATA,6,7))])
    
    if(input$month != 99) details <- filter(details, substr(DATA,6,7) == input$month) 
    
    if(is.null(input$waga) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) details <- filter(details, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    details
  
  })
  #####
  mtSummarised2 <- reactive({
    details <-o_id %>%
      filter(GRUPA_ALGORYTMU == mtSummarised1()[input$tabela_rows_selected, ]$GRUPA_ALGORYTMU) %>% 
      filter(DATA == mtSummarised1()[input$tabela_rows_selected, ]$DATA) %>%
      group_by(GRUPA_ALGORYTMU) 
    if(input$month != 99) details <- filter(details, substr(DATA,6,7) == input$month) 
    
    if(is.null(input$waga) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) details <- filter(details, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    details
  })
  
  mtSummarised3 <- reactive({
    details <-o_id %>%
      filter(GRUPA_ALGORYTMU == mtSummarised1()[input$tabela_rows_selected, ]$GRUPA_ALGORYTMU) %>% 
      group_by(GRUPA_ALGORYTMU)
    
    if(input$month != 99) details <- filter(details, substr(DATA,6,7) == input$month) 
    
    if(is.null(input$waga) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$WAGA_KONTROLI %in% input$waga])
    if(is.null(input$typ) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% alg$GRUPA_ALGORYTMU[alg$typ %in% input$typ])
    if(is.null(input$jed) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$JEDNOSTKA_ZGLASZAJACA %in% input$jed])
    if(is.null(input$mail) != TRUE) details <- filter(details, MNEMONIK_ODBIORCY %in% input$mail)
    if(is.null(input$kod) != TRUE) details <- filter(details, GRUPA_ALGORYTMU %in% met_kon$GRUPA_ALGORYTMU[met_kon$KOD_OBSZARU %in% input$kod])
    details
  })
  
  # Generate datatable
  output$tabela <- renderDataTable({
    brks <- quantile(mtSummarised1()$BLEDY, probs = seq(.05, .95, .05), na.rm = TRUE)
    clrs <- round(seq(255, 40, length.out = length(brks) + 1), 0) %>%
    {paste0("rgb(255,", ., ",", ., ")")}
    datatable(mtSummarised1(),
              escape = -2,
              extensions = c('FixedHeader', 'Buttons', 'ColReorder', 'Scroller'),
              options = list(
                dom = 'Bfrti',
                autoWidth = FALSE,
                colReorder = TRUE,
                deferRender = TRUE,
                scrollX = TRUE,
                scrollY = "51vh",
                scroller = TRUE,
                scollCollapse = TRUE,
                fixedHeader = TRUE,
                columnDefs = list(
                  list(orderable = FALSE, className = 'details-control', targets = 0)
                )
              ))%>%formatStyle('BLEDY', target = 'row',backgroundColor = styleInterval(brks, clrs))
    
  })
  
  output$tabela2 <- renderDataTable({
    brks <- quantile(mtSummarised2()$BLEDY, probs = seq(.05, .95, .05), na.rm = TRUE)
    clrs <- round(seq(255, 40, length.out = length(brks) + 1), 0) %>%
    {paste0("rgb(255,", ., ",", ., ")")}
    datatable(mtSummarised2(),
              escape = -2,
              extensions = c('FixedHeader', 'Buttons', 'ColReorder', 'Scroller'),
              options = list(
                dom = 'Bfrti',
                autoWidth = FALSE,
                colReorder = TRUE,
                deferRender = TRUE,
                scrollX = TRUE,
                scrollY = "51vh",
                scroller = TRUE,
                scollCollapse = TRUE,
                fixedHeader = TRUE,
                columnDefs = list(
                  list(orderable = FALSE, className = 'details-control', targets = 0)
                )
              ))%>%formatStyle('BLEDY', target = 'row',backgroundColor = styleInterval(brks, clrs))
    
  })
  
  
  output$plot3 <- renderPlotly({

    
    plot_ly(mtSummarised3(), x=~DATA, y=~BLEDY, color =~ID_ALGORYTMU, type ="scatter",mode = "lines"
    )%>%
      layout( margin = list(b = 80), xaxis = list(tickangle = 45))
    
  })
  
  #####
  
  
  
  observeEvent(input$bar_clicked,
               {
                 grupa <- input$bar_clicked[1]
                 tab_title <- paste(input$waga, 
                                    "-", grupa , 
                                    if(input$month != 99) paste("-" , month.name[as.integer(input$month)]))
                 
                 if(tab_title %in% tab_list == FALSE){
                   
                   appendTab(inputId = "tabs",
                             tabPanel(
                               tab_title,
                               dataTableOutput("tabela")
                             ),session = getDefaultReactiveDomain())
                   
                   tab_list <<- c(tab_list, tab_title)
                   
                 }
                 
                 updateTabsetPanel(session, "tabs", selected = tab_title)
                 
               })

  observeEvent(input$tabela_rows_selected,
               {
                 tab_title <- "ID Algorytmu"
                 
                 if (tab_title %in% tab_list == FALSE){
                   
                   appendTab(inputId = "tabs",
                             tabPanel(
                               tab_title,
                               dataTableOutput("tabela2"),
                               plotlyOutput("plot3")
                             ))
                   
                   tab_list <<- c(tab_list, tab_title)
                   
                 }
                 
                 updateTabsetPanel(session, "tabs", selected = tab_title)
                 
               })  

  
  observeEvent(input$remove,{
    # Use purrr's walk command to cycle through each
    # panel tabs and remove them
    tab_list %>%
      walk(~removeTab("tabs", .x))
    tab_list <<- NULL
  })
  
}





shinyApp(ui, server)