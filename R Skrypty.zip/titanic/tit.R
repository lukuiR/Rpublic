#titanic
library(tidyverse)
library(rpart)


gender <- read_csv('titanic/gender_submission.csv')
training <- read_csv('titanic/train.csv')
test <- read_csv('titanic/test.csv')

training$Survived <- factor(training$Survived)
training$Pclass <- factor(training$Pclass)
training$Embarked <- factor(training$Embarked)
training$Sex <- factor(training$Sex)
training$Name <- NULL
training$Ticket <- NULL

training$Cabin <- substr(training$Cabin, 1, 1)

test$PassengerId <- NULL
test$Name <- NULL
test$Ticket <- NULL

test$Cabin <- substr(test$Cabin, 1, 1)

test$Survived <- factor(test$Survived)
test$Pclass <- factor(test$Pclass)
test$Embarked <- factor(test$Embarked)
test$Sex <- factor(test$Sex)

head(test,10)

rf1 <- randomForest(Survived ~ ., training, ntree=50, norm.votes=FALSE, na.action=na.omit)
rf2 <- randomForest(Survived ~ ., training, ntree=50, norm.votes=FALSE)
rf3 <- randomForest(Survived ~ ., training, ntree=50, norm.votes=FALSE)
rf.all <- combine(rf1, rf2, rf3)
print(rf.all)

summary(training)
summary(test)

fit <- rpart(Survived ~ .,data = training,control = rpart.control(minsplit = 5))

p <- round(predict(fit,test))
p=data.frame(p)
ps <- mutate(p, 
             Survived= case_when(X0 == 1 ~ 0,  X1 == 1 ~ 1)
)

pp = data.frame( test$PassengerId,ps$Survived)
colnames(pp)<-c("PassengerId","Survived")
as.table(pp[1:2,])

##################
library("DALEX")
head(apartments)

head(apartmentsTest)

summary(apartments)

titanic <- training %>%
  mutate(.,Pclass=factor(Pclass),
         Survived=factor(Survived),
         age=ifelse(is.na(Age),35,Age),
         age = cut(age,c(0,2,5,9,12,15,21,55,65,100)),
         Cabin = substr(training$Cabin, 1, 1),
         cn = as.numeric(gsub('[[:space:][:alpha:]]','',Cabin)),
         oe=factor(ifelse(!is.na(cn),cn%%2,-1)),
         train = sample(c(TRUE,FALSE),
                        size=891,
                        replace=TRUE, 
                        prob=c(.9,.1)   ) )
test <- test %>%
  mutate(.,Pclass=factor(Pclass),
         age=ifelse(is.na(Age),35,Age),
         age = cut(age,c(0,2,5,9,12,15,21,55,65,100)),
         A=grepl('A',Cabin),
         B=grepl('B',Cabin),
         C=grepl('C',Cabin),
         D=grepl('D',Cabin),
         cn = as.numeric(gsub('[[:space:][:alpha:]]','',Cabin)),
         oe=factor(ifelse(!is.na(cn),cn%%2,-1)),
         Embarked=factor(Embarked,levels=levels(titanic$Embarked))
  )
test$Fare[is.na(test$Fare)]<- median(titanic$Fare)

# create a linear model
apartments_lm_model <- lm(Survived ~ Cabin + Sex + Pclass + SibSp +  Parch + Fare + Embarked + Age, data = training)

summary(apartments_lm_model)

explainer_lm <- explain(apartments_lm_model,
                        data = training[,c(3,5:7,9:11)], y = training$Survived)
explainer_lm

