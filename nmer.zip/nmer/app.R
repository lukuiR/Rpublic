#dt ext https://rstudio.github.io/DT/extensions.html
#DT ino: https://yihui.shinyapps.io/DT-info/
###
library(shiny)
library(shinydashboard)
library(shinyWidgets)
library(plotly)
library(readxl)
library(data.table)
library(DT)
library(tidyverse)

source('prep_dat.R')

title <- tags$a(href='https://www.sabic.com/en',
                tags$img(src="1sabic.png", height = '55'), target="_blank")

# Define UI for application that draws a histogram
ui <- dashboardPage(
  skin = "black",
  dashboardHeader(title = title ,titleWidth = 200
                  ,tags$li(class= 'dropdown',
                           tags$style(".main-header {max-height: 55px;}"),
                           tags$style(".main-header .logo {height: 55px;}"),
                           tags$style(".sidebar-toggle {height: 55px; padding-top: 18px !important;}"),
                           tags$style(".navbar {min-height:55px !important}"),
                           tags$style(".navbar-custom-menu, .main-header .navbar-right {float: left !important;}"),HTML( '<b><font color=#ffffff> <font size="6"> Strategic Workforce Planning Tool</font></font></b>'))
  ),
  dashboardSidebar(
    width = 200,
    #####
    tags$style(".left-side, .main-sidebar {padding-top: 55px}"),
    #tags$style(".left-side, .main-sidebar {width: 200px}"),
    sidebarMenu(
      id = "tabs",
      menuItem("Instruction", icon = icon("info"), tabName = "tab1"),
      menuItem("Model Setup", icon = icon("glyphicon glyphicon-cog", lib ='glyphicon'), tabName = "tab2"),
      menuItem("Executive View", icon = icon("line-chart"), tabName = "tab3"),
      menuItem("Deep Dive View", icon = icon("glyphicon glyphicon-stats", lib ='glyphicon'), tabName = "tab4"),
      menuItem("Data View", icon = icon("glyphicon glyphicon-folder-open", lib ='glyphicon'), tabName = "tab5")
    )
    #####
  ),
  # end
  #dashbody                                
  dashboardBody(
    tabItems(
      #tab1
      #####
      tabItem(tabName = "tab1",includeCSS("styles.css"),
              h3('instruction')
      ),
      #####
      #end tab1
      #tab2
      ######
      tabItem(tabName = "tab2",
              fluidRow(
                box(
                  title =HTML( '<font color=#ffffff> <font size="5">Global Parameters</font></font>')
                  , status = "primary", solidHeader = TRUE,width = '100%',
                  tabBox(
                    # The id lets us use input$tabset1 on the server to find the current tab
                    id = "tabset1", width = '100%',# height = "250px",
                    tabPanel("Training",
                             {
                               box(status = "primary", width = '100%',
                                   actionButton("reset_ld","Reset L&D"),
                                   # fluidRow(
                                   #   dataTableOutput(outputId = "tld")
                                   # ),
                                   fluidRow(
                                     column(2,br(),br(),h5('Total L&D Spend / FTE')),
                                     column(2,
                                            textInput("MEA", h5("Year 1 Value"),
                                                      value = ld$`T=1` #"1250"
                                                      )) ,
                                     column(2,
                                            textInput("APAC", h5("Year 2 Value"), 
                                                      value = ld$`T=2` #"1250"
                                            )) ,
                                     column(2,
                                            textInput("AMR", h5("Year 3 Value"),
                                                      value = ld$`T=3` #"1250"
                                            )) ,
                                     column(2,
                                            textInput("EUR", h5("Year 4 Value"),
                                                      value = ld$`T=4` #"1250"
                                            )) ,
                                     column(2,
                                            textInput("EUR", h5("Year 5 Value"),
                                                      value = ld$`T=5` #"1250"
                                            )) 
                                   )
                               )
                             }
                    ),
                    tabPanel("Supply", 
                             {
                             box(status = "primary",width = 12,
                                 actionButton("reset_nhr","Reset Demand NHR"),
                                 fluidRow(
                                   dataTableOutput(outputId = "tnhr")
                                 ),
                                 {fluidRow(
                                   column(1,br(),br(),h5(2018)),
                                   
                                   column(2, 
                                          sliderInput("MEA2", "MEA:",
                                                      min = -100, max = 100,
                                                      value = nhr$MEA[1]*100,pre = "%", step = 0.01, ticks = FALSE)) ,
                                   
                                   column(2, 
                                          sliderInput("APAC2", "APAC:",
                                                      min = -100, max = 100,
                                                      value = nhr$APAC[1]*100,pre = "%", step = 0.01, ticks = FALSE)) ,
                                   
                                   column(2, 
                                          sliderInput("AMR2", "AMR:",
                                                      min = -100, max = 100,
                                                      value = nhr$AMR[1]*100,pre = "%", step = 0.01, ticks = FALSE)) ,
                                   
                                   column(2, 
                                          sliderInput("EUR2", "EUR:",
                                                      min = -100, max = 100,
                                                      value = nhr$EUR[1]*100,pre = "%", step = 0.01, ticks = FALSE))   
                                 )},
                                 {fluidRow(
                                   column(1,br(),br(),h5(2018)),
                                   
                                   column(2, 
                                          textInput("MEA", h5("MEA"), 
                                                    value = nhr$MEA[1] #"1.1"
                                                    )) ,
                                   
                                   column(2, 
                                          textInput("APAC", h5("APAC"), 
                                                    value = nhr$APAC[1] #"1.2"
                                                    )) ,
                                   
                                   column(2, 
                                          textInput("AMR", h5("AMR"), 
                                                    value = nhr$AMR[1] #"20"
                                                    )) ,
                                   
                                   column(2, 
                                          textInput("EUR", h5("EUR"), 
                                                    value = nhr$EUR[1] #"4"
                                                    ))   
                                 )},
                                 {fluidRow(
                                   column(1,h5(2019)),
                                   
                                   column(2, 
                                          textInput("MEA",NULL,# h5("MEA"), 
                                                    value = "1.1")) ,
                                   
                                   column(2, 
                                          textInput("APAC",NULL,# h5("APAC"), 
                                                    value = "1.2")) ,
                                   
                                   column(2, 
                                          textInput("AMR",NULL,# h5("AMR"), 
                                                    value = "20")) ,
                                   
                                   column(2, 
                                          textInput("EUR",NULL,# h5("EUR"), 
                                                    value = "4"))   
                                 )
                                 },
                                 {fluidRow(
                                   column(1,h5(2020)),
                                   
                                   column(2, 
                                          textInput("MEA",NULL,# h5("MEA"), 
                                                    value = "1.1")) ,
                                   
                                   column(2, 
                                          textInput("APAC",NULL,# h5("APAC"), 
                                                    value = "1.2")) ,
                                   
                                   column(2, 
                                          textInput("AMR",NULL,# h5("AMR"), 
                                                    value = "20")) ,
                                   
                                   column(2, 
                                          textInput("EUR",NULL,# h5("EUR"), 
                                                    value = "4"))   
                                 )
                                 })
                             },
                             #end
                             #knobInput nhr
                             {
                               fluidRow(
                                 box(title="Supply rate adjustments:",solidHeader = TRUE, status="primary",colour="light blue",
                                     fluidRow(column(6,
                                                     knobInput(
                                                       inputId = "hire_rate_y1",label = "Year 1 hire percentage:",
                                                       value = 0,min = -100, max = 100, step = 0.1, displayPrevious = TRUE,lineCap = "round",
                                                       fgColor = "#42cb69",angleOffset = -135,angleArc=270,inputColor = "#42cb69")),
                                              column(6,
                                                     knobInput(
                                                       inputId = "exit_rate_y1",label = "Year 1 exit percentage:",
                                                       value = 0,min = 0,max=50,displayPrevious = TRUE,lineCap = "round",
                                                       fgColor = "#c9413f",angleOffset = -135,angleArc=270,inputColor = "#c9413f"))
                                     ),
                                     fluidRow(column(6,
                                                     knobInput(
                                                       inputId = "hire_rate_y2",label = "Year 2 hire percentage:",
                                                       value = 0,min = 0,max=50,displayPrevious = TRUE,lineCap = "round",
                                                       fgColor = "#42cb69",angleOffset = -135,angleArc=270,inputColor = "#42cb69")),
                                              column(6,
                                                     knobInput(
                                                       inputId = "exit_rate_y2",label = "Year 2 exit percentage:",
                                                       value = 0,min = 0,max=50,displayPrevious = TRUE,lineCap = "round",
                                                       fgColor = "#c9413f",angleOffset = -135,angleArc=270,inputColor = "#c9413f"))
                                     ),
                                     fluidRow(column(6,
                                                     knobInput(
                                                       inputId = "hire_rate_y3",label = "Year 3 hire percentage:",
                                                       value = 0,min = 0,max=50,displayPrevious = TRUE,lineCap = "round",
                                                       fgColor = "#42cb69",angleOffset = -135,angleArc=270,inputColor = "#42cb69")),
                                              column(6,
                                                     knobInput(
                                                       inputId = "exit_rate_y3",label = "Year 3 exit percentage:",
                                                       value = 0,min = 0,max=50,displayPrevious = TRUE,lineCap = "round",
                                                       fgColor = "#c9413f",angleOffset = -135,angleArc=270,inputColor = "#c9413f"))
                                     ),
                                     width=12
                                 ))
                             }
                             #knf
                             
                    )
                  )
                )
              ),
              fluidRow(
                box( width = 14,status = "primary",column(2,selectInput("div",label='Division',choices=unique(db$Division), multiple = TRUE)),
                     column(2,selectInput("rg",label=HTML('<font color=#454545>Region</font>'),choices=unique(db$Region), multiple = TRUE)),
                     column(2,selectInput("Function Type",label=HTML('<font color=#454545>Function Type</font>'),choices=unique(db$`CF/SBU/AFF`), multiple = TRUE)),
                     column(2,selectInput("Function Name",label=HTML('<font color=#454545>Function Name</font>'),choices=unique(db$`CF/SBU/AFF Name`), multiple = TRUE)),
                     column(2,selectInput("Family",label=HTML('<font color=#454545>Family Name</font>'),choices=unique(db$Family), multiple = TRUE)),
                     column(2,selectInput("Sub",label=HTML('<font color=#454545>Sub-Family</font>'),choices=unique(db$`Sub Family`), multiple = TRUE))
                ),{
                box( width = 14,status = "primary",
                       column(4,pickerInput("pdiv",label='Division',choices=unique(db$Division),selected = unique(db$Division), options = list(
                         `actions-box` = TRUE, 
                         size = 10,
                         `selected-text-format` = "count > 3"
                       ), multiple = TRUE)),
                       column(4,pickerInput("prg",label=HTML('<font color=#454545>Region</font>'),choices=unique(db$Region),selected = unique(db$Region),options = list(
                         `actions-box` = TRUE, 
                         size = 10,
                         `selected-text-format` = "count > 3"
                       ),  multiple = TRUE)),
                       column(4,pickerInput("pType",label=HTML('<font color=#454545>Function Type</font>'),choices=unique(db$`CF/SBU/AFF`),options = list(
                         `actions-box` = TRUE, 
                         size = 10,
                         `selected-text-format` = "count > 3"
                       ),  multiple = TRUE)),
                       column(4,pickerInput("pName",label=HTML('<font color=#454545>Function Name</font>'),choices=unique(db$`CF/SBU/AFF Name`),options = list(
                         `actions-box` = TRUE, 
                         size = 10,
                         `selected-text-format` = "count > 3"
                       ),  multiple = TRUE)),
                       column(4,pickerInput("Family",label=HTML('<font color=#454545>Family Name</font>'),choices=unique(db$Family),options = list(
                         `actions-box` = TRUE, 
                         size = 10,
                         `selected-text-format` = "count > 3"
                       ),  multiple = TRUE)),
                       column(4,pickerInput("pSub",label=HTML('<font color=#454545>Sub-Family</font>'),choices=unique(db$`Sub Family`),options = list(
                         `actions-box` = TRUE, 
                         size = 10,
                         `selected-text-format` = "count > 3"
                       ),multiple = TRUE))#https://stackoverflow.com/questions/51355878/how-to-text-wrap-choices-from-a-pickerinput-if-the-length-of-the-choices-are-lo
                )
                  },
                uiOutput('variables'),uiOutput('variables2')
              ),
              fluidRow(
                box(
                  title =HTML( '<font color=#ffffff> <font size="5">Specyfic Parameters</font></font>')
                  , status = "primary", solidHeader = TRUE,width = '100%',
                  tabBox(
                    # The id lets us use input$tabset1 on the server to find the current tab
                    id = "tabset1", height = "250px", width = '100%',
                    tabPanel("Demand",
                             actionButton("reset_d","Reset L&D"), "First tab content"),
                    tabPanel("Baseline Positioning",
                             actionButton("reset_b","Reset L&D"), "Tab content 2"),
                    tabPanel("Supply",
                             actionButton("reset_s","Reset L&D"), "Tab content 3"),
                    tabPanel("Training",
                             actionButton("reset_t","Reset L&D"), "Tab content 4")
                  )
                )
              )
      ),
      ######
      #end tab2
      #tab3
      ######
      tabItem(tabName = "tab3",
              fluidRow(
                box(
                  title =HTML( '<font color=#ffffff> <font size="5">Scenario Selection</font></font>')
                  , status = "primary", solidHeader = TRUE,
                  tags$style(HTML(".radio-inline {margin-right: 20%;color:#262626;}")),
                  radioButtons("radio1", label = NULL,
                               choiceNames = list("As-is", "Optimistic","Realistic"
                               ),
                               choiceValues = list(
                                 "rs", "r_opt_s","r_crvt_s"
                               ),selected = "rs", inline = TRUE),width = '60%'
                )
              ),
              box( status = "primary",
                   #actionButton("reset_t3_p","Whole Company"),
                          column(4,pickerInput("p3div",label='Division',choices=unique(db$Division),selected = unique(db$Division), options = list(
                            `actions-box` = TRUE, 
                            size = 10,
                            `selected-text-format` = "count > 3"
                          ), multiple = TRUE)),
                          column(4,pickerInput("p3rg",label=HTML('<font color=#454545>Region</font>'),choices=unique(db$Region),selected = unique(db$Region),options = list(
                            `actions-box` = TRUE, 
                            size = 10,
                            `selected-text-format` = "count > 3"
                          ),  multiple = TRUE)),
                          column(4,pickerInput("p3type",label=HTML('<font color=#454545>Function Type</font>'),choices=unique(db$`CF/SBU/AFF`),options = list(
                            `actions-box` = TRUE, 
                            size = 10,
                            `selected-text-format` = "count > 3"
                          ),  multiple = TRUE)),
                          column(4,pickerInput("p3name",label=HTML('<font color=#454545>Function Name</font>'),choices=unique(db$`CF/SBU/AFF Name`),options = list(
                            `actions-box` = TRUE, 
                            size = 10,
                            `selected-text-format` = "count > 3"
                          ),  multiple = TRUE)),
                          column(4,pickerInput("p3family",label=HTML('<font color=#454545>Family Name</font>'),choices=unique(db$Family),options = list(
                            `actions-box` = TRUE, 
                            size = 10,
                            `selected-text-format` = "count > 3"
                          ),  multiple = TRUE))
                   ,width = '100%'),
              fluidRow(
                column(3,pickerInput("p3emp",label=HTML('<font color=#454545>Employment</font>'),choices=c('Contractor','Direct Hire','NA'), multiple = TRUE)),        
                column(3,pickerInput("p3seg",label=HTML('<font color=#454545>Segment</font>'),choices=c('Core','Specialist','Support','Critical','NA'), multiple = TRUE))
              ),
              fluidRow(
                box(status = "primary", width = 12, 
                    radioButtons("radio_t3", label = HTML('<font color=#454545>Workforce Journey</font>'),
                                 choiceNames = list("plot 1","plot 2"
                                 ),
                                 choiceValues = list(
                                   'plot1',2
                                 ),selected = "plot1", inline = TRUE),
                    conditionalPanel(
                      condition = "input.radio_t3 == 'plot1'",
                      plotlyOutput("plot1")
                    ),
                    conditionalPanel(
                      condition = "input.radio_t3 == 2",
                      plotlyOutput("plot11")
                    )
                )
              ),
              fluidRow(
                box(status = "primary", width = 12, 
                    label='asd', h4('Scenario Comparison'),
                    plotlyOutput("plot2")
                )
              ),
              fluidRow(
                column(6, box(status = "primary", width = '100%', 
                    label='asd', h4('Gap Analysis'),
                    plotlyOutput("plot4")
                )),
                column(6, box(status = "primary", width = '100%', 
                    label='asd', h4('Forecast'),
                    plotlyOutput("plot44")
                ))
              )
      ),
      ######
      #end
      #tab4
      ######
      tabItem(tabName = "tab4",
              tabsetPanel(id = "tabs2",   
                          tabPanel(
                            title = "Section Selection",icon = icon("glyphicon glyphicon-saved",lib ="glyphicon"),
                            value = "page1",
                            fluidRow(
                              box(
                                title =HTML( '<font color=#ffffff> <font size="5">Scenario Selection</font></font>')
                                , status = "primary", solidHeader = TRUE,width = '100%',
                                tags$style(HTML(".radio-inline {margin-right: 20%;color:#262626;}")),
                                radioButtons("radiodd1", label = NULL,
                                             choiceNames = list("As-is", "Optimistic","Realistic"
                                             ),
                                             choiceValues = list(
                                               "As-is", "Optimistic","Realistic"
                                             ),selected = "Realistic", inline = TRUE)
                              )
                            ),
                            fluidRow(
                              box( width = '100%',status = "primary",column(2,selectInput("div",label=HTML('<font color=#454545>Division</font>'),choices=unique(iris$Species), multiple = TRUE)),
                                   column(2,selectInput("rg2",label=HTML('<font color=#454545>Region</font>'),choices=unique(iris$Species), multiple = TRUE)),
                                   column(3,selectInput("Function Type",label=HTML('<font color=#454545>Function Type</font>'),choices=unique(iris$Species), multiple = TRUE)),
                                   column(3,selectInput("Function Name",label=HTML('<font color=#454545>Function Name</font>'),choices=unique(iris$Species), multiple = TRUE)),
                                   column(2,selectInput("Family",label=HTML('<font color=#454545>Family Name</font>'),choices=unique(iris$Species), multiple = TRUE))
                              )
                            ),
                            fluidRow(
                              column(3,selectInput("emp",label=HTML('<font color=#454545>Employment</font>'),choices=unique(iris$Species), multiple = TRUE)),        
                              column(3,selectInput("seg",label=HTML('<font color=#454545>Segment</font>'),choices=unique(iris$Species), multiple = TRUE))
                            )
                            
                          ),
                          tabPanel("Section Summary", icon = icon("line-chart") 
                                   
                          ),
                          tabPanel("Workflow Jurney", icon = icon("line-chart"), 
                                   fluidRow(
                                     box(status = "primary", radioButtons("radio2", label = HTML('<font color=#454545>Workforce Journey</font>'),
                                                                          choiceNames = list("plot 1","plot 2"
                                                                          ),
                                                                          choiceValues = list(
                                                                            "Optimistic","Realistic"
                                                                          ), inline = TRUE),
                                         h1('plot')
                                     )
                                   )
                          ),
                          tabPanel("Workflow Forcast", icon = icon("line-chart") 
                                   
                          )
              )
      ),
      ######
      #end
      #tab5
      ######
      tabItem(tabName = "tab5",
              conditionalPanel(condition="$('html').hasClass('shiny-busy')",
                               tags$div("Loading...",HTML('<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
                                                          <span class="sr-only">Loading...</span>'),id="loadmessage")),
              align = "center",
              uiOutput("KKosz")
                               )
      ######
      #end
    )
  )
  )
##########

# Define server logic required to draw a histogram
server <- function(input, output) {
  
  aoc<-reactive({
    z=0
    if(input$radio1=="rs"){
      z=rs
    }
    if(input$radio1=="r_opt_s"){
      z=r_opt_s
    }
    else{
      z=r_crvt_s
    }
  })
  
  observeEvent(input$reset_dd,{
    #f_pull_dd(rvalues$dd_raw)
  })
  
  #filter
  #####
  dataset<-reactive({
    z <- db
    
    z <- z[z$Division %in%  if(is.null(input$variables2)){unique(db$Division)} else (input$variables2) ,]
  })
  outVar <- reactive({
    vars <- unique(db$Division)
    return(vars)
  })
  
  outVar2 <- reactive({
    vars <- unique(dataset()$Region)
    return(vars)
  })
  
  output$variables = renderUI({
    selectInput('variables2', 'Division', outVar(), multiple = TRUE)
  })
  output$variables2 = renderUI({
   selectInput('variables3', 'Region', outVar2(), multiple = TRUE)
  })

  #####
  
  #plot
  #####
  output$plot11<- renderPlotly({
    x <- c('1.Current<br>headcount', '1.Current<br>headcount', '2.Addition',  '3.Substraction', '4.Automation', '5.Final')
    y <- c(300, 410, 660,  590, 400,  340)
    base <- c(0, 0, 430,  570, 370,  0)
    revenue <- c(320, 110, 260,  0, 0,  0)
    costs <- c(0, 0, 0,  120, 200, 0)
    profit <- c(0, 0, 0, 0, 0, 370)
    text <- c('$320K','$430K', '$260K', '$-120K', '$-200K', '$370K')
    data <- data.frame(x, base, revenue, costs, profit, text)
    
    #The default order will be alphabetized unless specified as below:
    
    plot_ly(data, x = ~x, y = ~base, type = 'bar', marker = list(color = 'rgba(1,1,1, 0.0)'))%>%
      add_trace(y = ~revenue, marker = list(color = 'rgba(55, 128, 191, 0.7)',
                                            line = list(color = 'rgba(55, 128, 191, 0.7)',
                                                        width = 2))) %>%
      add_trace(y = ~costs, marker = list(color = 'rgba(219, 64, 82, 0.7)',
                                          line = list(color = 'rgba(219, 64, 82, 1.0)',
                                                      width = 2))) %>%
      add_trace(y = ~profit, marker = list(color = 'rgba(50, 171, 96, 0.7)',
                                           line = list(color = 'rgba(50, 171, 96, 1.0)',
                                                       width = 2))) %>%
      layout(title = 'Headcount',
             xaxis = list(title = ""),
             yaxis = list(title = ""),
             barmode = 'stack',
             #  paper_bgcolor = 'rgba(245, 246, 249, 1)',
             # plot_bgcolor = 'rgba(245, 246, 249, 1)',
             showlegend = FALSE) %>%
      add_annotations(text = text,
                      x = x,
                      y = y,
                      xref = "x",
                      yref = "y",
                      font = list(family = 'Arial',
                                  size = 14,
                                  color = 'rgba(245, 246, 249, 1)'),
                      showarrow = FALSE)
  })
  
  output$plot1<- renderPlotly({
    aoc()
    x <- c('1.Current<br>headcount', '2.Addition',  '3.Substraction', '4.Y0 Baseline','5.Demand','6.Training','7.Automation','8.Y5 FINAL')
    #y <- c(sum(rs$total), sum(rs$total)+sum(rs$addt),sum(rs$total)+sum(rs$addt)-sum(rs$subt), sum(rs$total)+sum(rs$addt)-sum(rs$subt),sum(rs$total),sum(rs$fte5),7,8)
    
    base <-    c(0,                sum(aoc()$total),                sum(aoc()$total)-sum(aoc()$subt), 0, sum(aoc()$dds19), sum(aoc()$fte1), sum(aoc()$sray23),0)
    revenue <- c(sum(aoc()$total), sum(aoc()$addt)-sum(aoc()$subt), 0,                                0, 0,  0,7,sum(aoc()$dsay23))
    costs <-   c(0,                0,                               sum(aoc()$subt),                  0,sum(aoc()$total)-sum(aoc()$subt)-sum(aoc()$dds19),sum(aoc()$dds19)-sum(aoc()$fte1),7,0)
    profit <-  c(0,                0,                               0,                                sum(aoc()$total)-sum(aoc()$subt),0,0,0,sum(aoc()$dsray23))
    #text <- c('non','core', 'Specialist', 'Support', 'Critical', 'add',  '3.Substraction', '4.Y0 Baseline','5.Automation','6.Training','7.Demand','8.Y5 FINAL')
    data <- data.frame(x, base, revenue, costs, profit)
    
    #The default order will be alphabetized unless specified as below:
    
    plot_ly(data, x = ~x, y = ~base, type = 'bar', marker = list(color = 'rgba(1,1,1, 0.0)'))%>%
      add_trace(y = ~revenue, marker = list(color = 'rgba(252, 157, 13, 0.7)',
                                            line = list(color = 'rgba(252, 157, 13, 0.7)',
                                                        width = 2))) %>%
      add_trace(y = ~costs, marker = list(color = 'rgba(219, 64, 82, 0.7)',
                                          line = list(color = 'rgba(219, 64, 82, 1.0)',
                                                      width = 2))) %>%
      add_trace(y = ~profit, marker = list(color = 'rgba(2, 69, 186, 0.7)',
                                           line = list(color = 'rgba(2, 69, 186, 1.0)',
                                                       width = 2))) %>%
      layout(title = 'Headcount',
             xaxis = list(title = ""),
             yaxis = list(title = ""),
             barmode = 'stack',
             #  paper_bgcolor = 'rgba(245, 246, 249, 1)',
             # plot_bgcolor = 'rgba(245, 246, 249, 1)',
             showlegend = FALSE) 
  })

  output$plot2<- renderPlotly({
    x <- c('T1', 'T2', 'T3', 'T4', 'T5')
    As_is <- c(sum(rs$fte1), sum(rs$fte2),sum(rs$fte3),sum(rs$fte4),sum(rs$fte5))
    Opt <- c(sum(r_opt_s$fte1), sum(r_opt_s$fte2),sum(r_opt_s$fte3),sum(r_opt_s$fte4),sum(r_opt_s$fte5))
    Con <- c(sum(r_crvt_s$fte1), sum(r_crvt_s$fte2),sum(r_crvt_s$fte3),sum(r_crvt_s$fte4),sum(r_crvt_s$fte5))
    data <- data.frame(x, Opt, Con, As_is)
  plot_ly(data, x = ~x, y = ~As_is, type = 'bar',name='As is', marker = list(color = 'rgba(55, 128, 191, 0.7)'))%>%
    add_trace(y = ~Opt,name='Optimistic', marker = list(color = 'rgba(100, 200, 23, 0.7)',
                                                        line = list(color = 'rgba(100, 200, 23, 0.7)',
                                                                    width = 2))) %>%
    add_trace(y = ~Con,name='Realistic', marker = list(color = 'rgba(219, 64, 82, 0.7)',
                                                       line = list(color = 'rgba(219, 64, 82, 1.0)',
                                                                   width = 2)))%>%
    layout(title = 'Headcount',
           xaxis = list(title = ""),
           yaxis = list(title = ""))
  })
  
  output$plot4<- renderPlotly({
    aoc()
    x <- c('T1', 'T2', 'T3', 'T4', 'T5')
    As_is <- c(sum(aoc()$fte1), sum(aoc()$fte2),sum(aoc()$fte3),sum(aoc()$fte4),sum(aoc()$fte5))
    Opt <- c(sum(aoc()$sels), sum(aoc()$sray19),sum(aoc()$sray20),sum(aoc()$sray21),sum(aoc()$sray22))
    data <- data.frame(x, Opt,  As_is)
    plot_ly(data, x = ~x, y = ~Opt, type = 'bar',name='Demand',marker = list(color = 'rgba(55, 128, 191, 0.7)'))%>%
      add_trace(y = ~As_is, name='Supply',  marker = list(color = 'rgba(100, 200, 23, 0.7)',
                                                          line = list(color = 'rgba(100, 200, 23, 0.7)',
                                                                      width = 2))) %>%
      layout(title = 'Headcount',
             xaxis = list(title = ""),
             yaxis = list(title = ""))
  })
  
  output$plot44<- renderPlotly({
    x <- c('T0','T1', 'T2', 'T3', 'T4', 'T5')
    Opt <- c(sum(r_opt_s$total), sum(r_opt_s$sray19),sum(r_opt_s$sray20),sum(r_opt_s$sray21),sum(r_opt_s$sray22),sum(r_opt_s$sray23))
    crvt <- c(sum(r_crvt_s$total), sum(r_crvt_s$sray19),sum(r_crvt_s$sray20),sum(r_crvt_s$sray21),sum(r_crvt_s$sray22),sum(r_crvt_s$sray23))
    As_is <- c(sum(rs$total), sum(rs$sray19),sum(rs$sray20),sum(rs$sray21),sum(rs$sray22),sum(rs$sray23))
    data <- data.frame(x, Opt,  As_is,crvt)
    plot_ly(data, x = ~x, y = ~Opt, type = 'scatter',mode = "lines",name='opt',marker = list(color = 'rgba(55, 128, 191, 0.7)'))%>%
      add_trace(y = ~As_is, name='asis',  marker = list(color = 'rgba(200, 0, 23, 0.7)',width = 2),
                                                          line = list(color = 'rgba(200, 0, 23, 0.7)'))%>%
      add_trace(y = ~crvt, name='crvt',  marker = list(color = 'rgba(100, 200, 23, 0.7)',
                                                          line = list(color = 'rgba(100, 200, 23, 0.7)',
                                                                      width = 2))) %>%
      layout(title = 'Forecast',
             xaxis = list(title = ""),
             yaxis = list(title = ""))
  })
  #####
  #end
  
  #table
  #####
  #nhr
  #####
  output$tnhr<- renderDataTable({
    datatable(nhr,rownames = FALSE,
              options = list(
                #dom = 'Bfrti',
                autoWidth = FALSE,
                deferRender = TRUE,
                scrollX = TRUE,
                scrollY = "51vh",
                scroller = TRUE,
                scollCollapse = TRUE,
                fixedHeader = TRUE,
                columnDefs = list(
                  list(orderable = FALSE, className = 'details-control', targets = 0)
                )
              ) ,escape=F
    )%>%
      formatPercentage(c('MEA','AMR','EUR','APAC'), 2)
  })
  #####
  #end
  #ld
  #####
  output$tld<- renderDataTable({
    datatable(ld,rownames = FALSE,
              options = list(
                #dom = 'Bfrti',
                autoWidth = FALSE,
                deferRender = TRUE,
                scrollX = TRUE,
                scrollY = "51vh",
                scroller = TRUE,
                scollCollapse = TRUE,
                fixedHeader = TRUE,
                columnDefs = list(
                  list(orderable = FALSE, className = 'details-control', targets = 0)
                )
              ) ,escape=F
    )%>%
    formatCurrency(c('T=0','T=1','T=2','T=3','T=4','T=5'),currency = "$", interval = 3, mark = ",", digits = 0)
  })
  #####
  #end
  
  #vals preparation
  ######
  vals=reactiveValues()
  vals$Data=data.table(db)
  
  newEntry1 <- observe(vals$Data <- mutate(vals$Data, 
                                           M_NHR= case_when(Region == "MEA" ~ input$MEA,  Region == "APAC" ~ input$APAC,
                                                            Region == "AMR" ~ input$AMR, Region == "EUR" ~ input$EUR)
  )
  )
  newEntry <- observe({vals$Data <- data.table(db[db$Region %in%  if(is.null(input$rg)){unique(db$Region)} else (input$rg),])
  vals$Data <- data.table(db[db$Division %in%  if(is.null(input$div)){unique(db$Division)} else (input$div) ,])
  })
  ######
  #end vals
  #####
  output$KKosz=renderUI({
    box(width=12,
        column(12,dataTableOutput("Main_kosz")),
        tags$script(HTML('$(document).on("click", "input", function () {
                         var checkboxes = document.getElementsByName("row_selected");
                         var checkboxesChecked = [];
                         for (var i=0; i<checkboxes.length; i++) {
                         if (checkboxes[i].checked) {
                         checkboxesChecked.push(checkboxes[i].value);
                         }
                         }
                         Shiny.onInputChange("checked_rows",checkboxesChecked);})')),
        tags$script("$(document).on('click', '#Main_kosz button', function () {
                    Shiny.onInputChange('lastClickkId',this.id);
                    Shiny.onInputChange('lastClickk', Math.random()) });")
        
        )
    })
  
  output$Main_kosz=renderDataTable({ DT=vals$Data[] 
  
  datatable(DT[],
            options = list(
              #dom = 'Bfrti',
              autoWidth = FALSE,
              deferRender = TRUE,
              scrollX = TRUE,
              scrollY = "51vh",
              scroller = TRUE,
              scollCollapse = TRUE,
              fixedHeader = TRUE,
              columnDefs = list(
                list(orderable = FALSE, className = 'details-control', targets = 0)
              )
            ) ,escape=F)
  
  })
  
  #####action showModal
  observeEvent(input$lastClickk,
               {
                 showModal(modal_modify)
               }
  )
  #####
  ##modalDialog
  #####
  modal_modify=modalDialog(
    fluidPage(
      h3(strong("Row modification"),align="center"),
      hr(),
      dataTableOutput('row_modif'),
      actionButton("save_changes","Save"),
      tags$script(HTML("$(document).on('click', '#save_changes', function () {
                       var list_value=[]
                       for (i = 0; i < $( '.new_input' ).length; i++)
                       {
                       list_value.push($( '.new_input' )[i].value)
                       }
                       Shiny.onInputChange('newValue', list_value)
                       });"
                           ))
      
      
      ),
    size="m"
    )
  #####
  
  ##co modyfikuje
  output$row_modif<-renderDataTable({
    selected_row=as.numeric(gsub("modify_","",input$lastClickkId))
    old_row=vals$Data[selected_row,c('n','Manual')]
    row_change=list()
    row_change[[1]]=vals$Data[selected_row,c('n')]
    row_change[[2]]=paste0('<input class="new_input" type="number" id=new_',2,'><br>')
    row_change=as.data.table(row_change)
    setnames(row_change,colnames(old_row))
    DT=rbind(old_row,row_change)
    rownames(DT)<-c("Current values","New values")
    DT
    
  },escape=F,options=list(dom='t',ordering=F),selection="none")
  
  ##data table update by modification
  ######
  observeEvent(input$newValue,
               {
                 newValue=lapply(input$newValue, function(col) {
                   if (suppressWarnings(all(!is.na(as.numeric(as.character(col)))))) {
                     as.numeric(as.character(col))
                   } else {
                     col
                   }
                 })
                 DF=data.frame(lapply(newValue, function(x) t(data.frame(x))))
                 #dataset()[as.numeric(gsub("modify_","",input$lastClickkId)),'Manual']<-DF
                 
                 vals$Data[as.numeric(gsub("modify_","",input$lastClickkId)),'Manual']<-DF
               }
  )
  ######
  
  #####
  #end tb
  }

# Run the application 
shinyApp(ui = ui, server = server)
